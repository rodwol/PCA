# alumathpeergroup7

Matrix multiplication library.

## Installation
```bash
pip install alumathp7
