import numpy as np

def multiply(A, B):
    return np.dot(A, B)
